﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cyotek ImageBox Control Designer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Cyotek Ltd")]
[assembly: AssemblyProduct("Cyotek ImageBox Control")]
[assembly: AssemblyCopyright("Copyright © 2013-2015 Cyotek Ltd.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("3cadaf8e-61b8-407c-a82d-0d29f70ce38f")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
